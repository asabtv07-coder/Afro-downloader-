import express from 'express';
import type { Request, Response } from 'express';
import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import type {
  DownloadJobStatus,
  InspectedMedia,
  QualityOption,
} from './src/types.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';
const BIN_DIR = path.join(__dirname, '.bin');
const LOCAL_YTDLP = path.join(BIN_DIR, 'yt-dlp');
const JOBS_ROOT = path.join(os.tmpdir(), 'framevault-jobs');

interface InternalJob extends DownloadJobStatus {
  dir: string;
  filePath: string | null;
  createdAt: number;
  listeners: Set<Response>;
}

const jobs = new Map<string, InternalJob>();

function isPrivateOrBlockedHost(hostname: string): boolean {
  const lower = hostname.toLowerCase();
  if (
    lower === 'localhost' ||
    lower === '127.0.0.1' ||
    lower === '::1' ||
    lower === '0.0.0.0' ||
    lower.endsWith('.local') ||
    lower.endsWith('.internal')
  ) {
    return true;
  }

  if (net.isIPv4(lower)) {
    const parts = lower.split('.').map(Number);
    if (parts[0] === 10) return true;
    if (parts[0] === 127) return true;
    if (parts[0] === 0) return true;
    if (parts[0] === 169 && parts[1] === 254) return true;
    if (parts[0] === 192 && parts[1] === 168) return true;
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  }

  if (net.isIPv6(lower)) {
    if (lower === '::1' || lower.startsWith('fc') || lower.startsWith('fd') || lower.startsWith('fe80')) {
      return true;
    }
  }

  return false;
}

function validatePublicUrl(rawUrl: string): URL {
  const trimmed = rawUrl.trim();
  const parsed = new URL(trimmed);
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('Only HTTP and HTTPS video URLs are supported.');
  }
  if (isPrivateOrBlockedHost(parsed.hostname)) {
    throw new Error('Private or local network URLs cannot be accessed.');
  }
  return parsed;
}

async function resolveYtDlpPath(): Promise<string> {
  if (fs.existsSync(LOCAL_YTDLP)) {
    return LOCAL_YTDLP;
  }
  // Fallback to downloading yt-dlp binary into .bin/yt-dlp if missing
  await fsp.mkdir(BIN_DIR, { recursive: true });
  const arch = process.arch === 'arm64' ? 'yt-dlp_linux_aarch64' : 'yt-dlp_linux';
  const downloadUrl = `https://github.com/yt-dlp/yt-dlp/releases/latest/download/${arch}`;
  const resp = await fetch(downloadUrl);
  if (!resp.ok) {
    throw new Error('Could not initialize media extractor binary.');
  }
  const buffer = Buffer.from(await resp.arrayBuffer());
  await fsp.writeFile(LOCAL_YTDLP, buffer);
  await fsp.chmod(LOCAL_YTDLP, 0o755);
  return LOCAL_YTDLP;
}

async function withTempCookiesFile<T>(
  cookiesText: string | undefined,
  fn: (cookiePath: string | null) => Promise<T>,
): Promise<T> {
  if (!cookiesText || !cookiesText.trim()) {
    return fn(null);
  }
  const cookiePath = path.join(os.tmpdir(), `fv-cookies-${crypto.randomUUID()}.txt`);
  await fsp.writeFile(cookiePath, cookiesText.trim() + '\n', { mode: 0o600 });
  try {
    return await fn(cookiePath);
  } finally {
    await fsp.rm(cookiePath, { force: true }).catch(() => {});
  }
}

function runCommand(
  cmd: string,
  args: string[],
  timeoutMs = 45000,
): Promise<{ code: number; stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';

    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new Error('Media inspection timed out.'));
    }, timeoutMs);

    child.stdout.on('data', (chunk: Buffer) => {
      stdout += chunk.toString();
    });
    child.stderr.on('data', (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    child.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      resolve({ code: code ?? 1, stdout, stderr });
    });
  });
}

function detectPlatformName(extractorKey: string | undefined, rawUrl: string): string {
  const key = (extractorKey || '').toLowerCase();
  if (key.includes('youtube')) return 'YouTube';
  if (key.includes('tiktok')) return 'TikTok';
  if (key.includes('instagram')) return 'Instagram';
  if (key.includes('twitter') || key === 'x') return 'X (Twitter)';
  if (key.includes('reddit')) return 'Reddit';
  if (key.includes('facebook')) return 'Facebook';
  if (key.includes('vimeo')) return 'Vimeo';
  if (key.includes('twitch')) return 'Twitch';
  if (key.includes('threads')) return 'Threads';
  if (key.includes('bluesky')) return 'Bluesky';
  if (key.includes('pinterest')) return 'Pinterest';

  try {
    const host = new URL(rawUrl).hostname.replace(/^www\./, '');
    if (host.includes('youtu.be') || host.includes('youtube.com')) return 'YouTube';
    if (host.includes('tiktok.com')) return 'TikTok';
    if (host.includes('instagram.com')) return 'Instagram';
    if (host.includes('x.com') || host.includes('twitter.com')) return 'X (Twitter)';
    if (host.includes('reddit.com') || host.includes('redd.it')) return 'Reddit';
    if (host.includes('facebook.com') || host.includes('fb.watch')) return 'Facebook';
    if (host.includes('vimeo.com')) return 'Vimeo';
    return host;
  } catch {
    return 'Direct Media';
  }
}

interface RawYtDlpFormat {
  format_id?: string;
  ext?: string;
  width?: number | null;
  height?: number | null;
  fps?: number | null;
  vcodec?: string;
  acodec?: string;
  tbr?: number | null;
  filesize?: number | null;
  filesize_approx?: number | null;
}

interface RawYtDlpInfo {
  title?: string;
  uploader?: string;
  channel?: string;
  uploader_id?: string;
  extractor_key?: string;
  extractor?: string;
  duration?: number | null;
  thumbnail?: string | null;
  webpage_url?: string;
  width?: number | null;
  height?: number | null;
  formats?: RawYtDlpFormat[];
  entries?: RawYtDlpInfo[];
}

function buildQualityOptions(info: RawYtDlpInfo): QualityOption[] {
  const rawFormats = info.formats || [];
  const duration = typeof info.duration === 'number' ? info.duration : null;

  const bestAudio = rawFormats
    .filter((f) => f.vcodec === 'none' && f.acodec && f.acodec !== 'none')
    .sort((a, b) => (b.tbr || 0) - (a.tbr || 0))[0];

  const audioSizeApprox =
    bestAudio?.filesize ||
    bestAudio?.filesize_approx ||
    (bestAudio?.tbr && duration ? Math.round((bestAudio.tbr * 1000 * duration) / 8) : 0);

  const buckets = new Map<number, RawYtDlpFormat>();
  for (const fmt of rawFormats) {
    const hasVideo = fmt.vcodec && fmt.vcodec !== 'none';
    const height = fmt.height || 0;
    if (!hasVideo || height <= 0) continue;

    const existing = buckets.get(height);
    const fmtScore =
      (fmt.ext === 'mp4' ? 1000 : 0) +
      (fmt.vcodec?.startsWith('avc') || fmt.vcodec?.startsWith('h264') ? 500 : 0) +
      (fmt.tbr || 0);
    const existingScore = existing
      ? (existing.ext === 'mp4' ? 1000 : 0) +
        (existing.vcodec?.startsWith('avc') || existing.vcodec?.startsWith('h264') ? 500 : 0) +
        (existing.tbr || 0)
      : -1;

    if (!existing || fmtScore > existingScore) {
      buckets.set(height, fmt);
    }
  }

  const sortedHeights = Array.from(buckets.keys()).sort((a, b) => b - a);
  const options: QualityOption[] = [];

  for (const height of sortedHeights) {
    const fmt = buckets.get(height)!;
    const width = fmt.width || Math.round((height * 16) / 9);
    const videoSize =
      fmt.filesize ||
      fmt.filesize_approx ||
      (fmt.tbr && duration ? Math.round((fmt.tbr * 1000 * duration) / 8) : null);

    const needsMuxedAudio = !fmt.acodec || fmt.acodec === 'none';
    const totalApprox =
      videoSize !== null ? videoSize + (needsMuxedAudio ? audioSizeApprox : 0) : null;

    let label = `${height}p`;
    let sublabel = 'Standard Definition';
    if (height >= 2160) {
      label = '4K (2160p)';
      sublabel = 'Ultra High Definition';
    } else if (height >= 1440) {
      label = '2K (1440p)';
      sublabel = 'Quad HD';
    } else if (height >= 1080) {
      label = '1080p';
      sublabel = 'Full HD';
    } else if (height >= 720) {
      label = '720p';
      sublabel = 'High Definition';
    } else if (height >= 480) {
      label = '480p';
      sublabel = 'Standard';
    } else {
      label = `${height}p`;
      sublabel = 'Compact';
    }

    const formatSelector = `bv*[height<=${height}][ext=mp4]+ba[ext=m4a]/bv*[height<=${height}]+ba/b[height<=${height}]/b`;

    options.push({
      id: `video-${height}`,
      label,
      sublabel,
      height,
      width,
      fps: fmt.fps ? Math.round(fmt.fps) : null,
      ext: 'mp4',
      vcodec: fmt.vcodec || 'h264',
      acodec: needsMuxedAudio ? bestAudio?.acodec || 'aac' : fmt.acodec || 'aac',
      filesizeApprox: totalApprox,
      formatSelector,
      isAudioOnly: false,
    });
  }

  if (options.length === 0) {
    options.push({
      id: 'video-best',
      label: info.height ? `${info.height}p Best` : 'Best Available Quality',
      sublabel: 'Highest Source Stream',
      height: info.height || 1080,
      width: info.width || 1920,
      fps: null,
      ext: 'mp4',
      vcodec: 'h264',
      acodec: 'aac',
      filesizeApprox: null,
      formatSelector: 'bv*+ba/b',
      isAudioOnly: false,
    });
  }

  // Always offer Audio-Only M4A option when formats exist
  if (bestAudio || options.length > 0) {
    options.push({
      id: 'audio-m4a',
      label: 'Audio Only',
      sublabel: 'High-Bitrate M4A',
      height: 0,
      width: 0,
      fps: null,
      ext: 'm4a',
      vcodec: 'none',
      acodec: bestAudio?.acodec || 'aac',
      filesizeApprox: audioSizeApprox > 0 ? audioSizeApprox : null,
      formatSelector: 'ba[ext=m4a]/ba/b',
      isAudioOnly: true,
    });
  }

  return options;
}

async function probeMediaUrlWithFfprobe(mediaUrl: string): Promise<InspectedMedia | null> {
  const { code, stdout } = await runCommand(
    'ffprobe',
    [
      '-v',
      'quiet',
      '-print_format',
      'json',
      '-show_format',
      '-show_streams',
      mediaUrl,
    ],
    20000,
  );
  if (code !== 0 || !stdout.trim()) return null;

  const parsed = JSON.parse(stdout) as {
    format?: { duration?: string; size?: string; bit_rate?: string; format_name?: string };
    streams?: Array<{
      codec_type?: string;
      codec_name?: string;
      width?: number;
      height?: number;
      avg_frame_rate?: string;
    }>;
  };

  const videoStream = parsed.streams?.find((s) => s.codec_type === 'video');
  const audioStream = parsed.streams?.find((s) => s.codec_type === 'audio');
  if (!videoStream && !audioStream) return null;

  const duration = parsed.format?.duration ? Number(parsed.format.duration) : null;
  const size = parsed.format?.size ? Number(parsed.format.size) : null;
  const height = videoStream?.height || 1080;
  const width = videoStream?.width || 1920;

  let fps: number | null = null;
  if (videoStream?.avg_frame_rate && videoStream.avg_frame_rate.includes('/')) {
    const [num, den] = videoStream.avg_frame_rate.split('/').map(Number);
    if (den > 0) fps = Math.round(num / den);
  }

  const parsedUrl = new URL(mediaUrl);
  const rawName = path.basename(parsedUrl.pathname) || 'Social_Video';
  const cleanTitle = decodeURIComponent(rawName.replace(/\.[a-z0-9]+$/i, '')).replace(/[_-]+/g, ' ');

  const formats: QualityOption[] = [
    {
      id: `video-${height}`,
      label: height >= 2160 ? '4K (2160p)' : height >= 1080 ? `${height}p` : `${height}p`,
      sublabel: height >= 1080 ? 'Full HD Source' : 'Original Source Stream',
      height,
      width,
      fps,
      ext: 'mp4',
      vcodec: videoStream?.codec_name || 'h264',
      acodec: audioStream?.codec_name || 'aac',
      filesizeApprox: size,
      formatSelector: 'best',
      isAudioOnly: false,
    },
  ];

  if (audioStream) {
    formats.push({
      id: 'audio-m4a',
      label: 'Audio Only',
      sublabel: 'Extracted M4A',
      height: 0,
      width: 0,
      fps: null,
      ext: 'm4a',
      vcodec: 'none',
      acodec: audioStream.codec_name || 'aac',
      filesizeApprox: size ? Math.round(size * 0.15) : null,
      formatSelector: 'audio',
      isAudioOnly: true,
    });
  }

  return {
    title: cleanTitle || 'Direct Video Stream',
    author: parsedUrl.hostname.replace(/^www\./, ''),
    platform: detectPlatformName(undefined, mediaUrl),
    duration,
    thumbnailUrl: null,
    webpageUrl: mediaUrl,
    width,
    height,
    formats,
    isDirectMedia: true,
  };
}

async function tryExtractOpenGraphVideo(pageUrl: string): Promise<string | null> {
  try {
    const resp = await fetch(pageUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml',
      },
      redirect: 'follow',
    });
    const contentType = resp.headers.get('content-type') || '';
    if (contentType.startsWith('video/') || contentType.includes('mpegurl')) {
      return resp.url || pageUrl;
    }
    if (!contentType.includes('text/html')) return null;
    const html = await resp.text();
    const patterns = [
      /<meta[^>]+property=["']og:video:secure_url["'][^>]+content=["']([^"']+)["']/i,
      /<meta[^>]+property=["']og:video["'][^>]+content=["']([^"']+)["']/i,
      /<meta[^>]+name=["']twitter:player:stream["'][^>]+content=["']([^"']+)["']/i,
      /<source[^>]+src=["']([^"']+\.mp4[^"']*)["']/i,
    ];
    for (const re of patterns) {
      const m = html.match(re);
      if (m?.[1]) {
        return new URL(m[1], pageUrl).toString();
      }
    }
    return null;
  } catch {
    return null;
  }
}

function formatYtDlpError(stderr: string): string {
  const lower = stderr.toLowerCase();
  if (lower.includes('sign in to confirm') || lower.includes('not a bot') || lower.includes('cookies')) {
    return 'This platform requested session verification from this server IP. Open "Session Cookies (Optional)" below and paste your browser cookies.txt to unlock and download it.';
  }
  if (lower.includes('logged-in') || lower.includes('login required') || lower.includes('private')) {
    return 'This video requires an authenticated account or is private. Add your session cookies in "Session Cookies (Optional)" to access it.';
  }
  if (lower.includes('unsupported url')) {
    return 'Unsupported URL or no downloadable video stream was found at that link.';
  }
  const cleanLine = stderr
    .split('\n')
    .find((line) => line.includes('ERROR:'))
    ?.replace(/^.*ERROR:\s*/, '')
    .trim();
  return cleanLine || 'Could not extract a downloadable video stream from this URL.';
}

function emitJobUpdate(job: InternalJob): void {
  const payload: DownloadJobStatus = {
    jobId: job.jobId,
    stage: job.stage,
    progress: job.progress,
    speed: job.speed,
    eta: job.eta,
    message: job.message,
    error: job.error,
    filename: job.filename,
    mimeType: job.mimeType,
    fileSize: job.fileSize,
    width: job.width,
    height: job.height,
    vcodec: job.vcodec,
    acodec: job.acodec,
    duration: job.duration,
  };
  const data = `data: ${JSON.stringify(payload)}\n\n`;
  for (const res of job.listeners) {
    try {
      res.write(data);
    } catch {
      job.listeners.delete(res);
    }
  }
}

function sanitizeFilename(raw: string, ext: string): string {
  const cleaned = raw
    .replace(/[^\w\s.-]+/g, '')
    .trim()
    .replace(/\s+/g, '_')
    .slice(0, 64);
  return `${cleaned || 'FrameVault_Video'}.${ext}`;
}

async function runFfprobeLocal(filePath: string): Promise<{
  width: number | null;
  height: number | null;
  vcodec: string | null;
  acodec: string | null;
  duration: number | null;
}> {
  const { code, stdout } = await runCommand(
    'ffprobe',
    ['-v', 'quiet', '-print_format', 'json', '-show_format', '-show_streams', filePath],
    15000,
  );
  if (code !== 0 || !stdout.trim()) {
    return { width: null, height: null, vcodec: null, acodec: null, duration: null };
  }
  const parsed = JSON.parse(stdout) as {
    format?: { duration?: string };
    streams?: Array<{ codec_type?: string; codec_name?: string; width?: number; height?: number }>;
  };
  const v = parsed.streams?.find((s) => s.codec_type === 'video');
  const a = parsed.streams?.find((s) => s.codec_type === 'audio');
  return {
    width: v?.width ?? null,
    height: v?.height ?? null,
    vcodec: v?.codec_name ?? null,
    acodec: a?.codec_name ?? null,
    duration: parsed.format?.duration ? Number(parsed.format.duration) : null,
  };
}

async function runFfmpegOptimize(
  job: InternalJob,
  inputPath: string,
  outputPath: string,
  needsTranscode: boolean,
  totalDurationSec: number | null,
): Promise<void> {
  const args = needsTranscode
    ? [
        '-y',
        '-i',
        inputPath,
        '-c:v',
        'libx264',
        '-preset',
        'fast',
        '-crf',
        '19',
        '-pix_fmt',
        'yuv420p',
        '-c:a',
        'aac',
        '-b:a',
        '192k',
        '-movflags',
        '+faststart',
        '-progress',
        'pipe:1',
        outputPath,
      ]
    : [
        '-y',
        '-i',
        inputPath,
        '-c',
        'copy',
        '-movflags',
        '+faststart',
        outputPath,
      ];

  await new Promise<void>((resolve, reject) => {
    const child = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stderr = '';
    child.stdout.on('data', (chunk: Buffer) => {
      const text = chunk.toString();
      const match = text.match(/out_time_ms=(\d+)/);
      if (match && totalDurationSec && totalDurationSec > 0) {
        const currentSec = Number(match[1]) / 1_000_000;
        const pct = Math.min(99, Math.max(1, Math.round((currentSec / totalDurationSec) * 100)));
        job.progress = pct;
        job.message = `Encoding gallery-ready H.264 MP4 (${pct}%)...`;
        emitJobUpdate(job);
      }
    });
    child.stderr.on('data', (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) resolve();
      else reject(new Error(stderr.slice(-400) || 'FFmpeg remuxing failed.'));
    });
  });
}

async function processDownloadJob(
  job: InternalJob,
  params: {
    url: string;
    formatSelector: string;
    isAudioOnly: boolean;
    galleryCompatible: boolean;
    title: string;
    heightLabel: string;
    cookies?: string;
    isDirectMedia?: boolean;
  },
): Promise<void> {
  try {
    await fsp.mkdir(job.dir, { recursive: true });
    job.stage = 'extracting';
    job.progress = 2;
    job.message = 'Connecting to media stream...';
    emitJobUpdate(job);

    const ytDlpPath = await resolveYtDlpPath();
    const outTemplate = path.join(job.dir, 'raw_media.%(ext)s');

    let downloadedFile: string | null = null;

    if (!params.isDirectMedia) {
      await withTempCookiesFile(params.cookies, async (cookiePath) => {
        const args = [
          '--no-playlist',
          '--newline',
          '--progress',
          '--no-warnings',
          '--ffmpeg-location',
          '/usr/bin/ffmpeg',
          '-o',
          outTemplate,
        ];

        if (cookiePath) {
          args.push('--cookies', cookiePath);
        }

        if (params.isAudioOnly) {
          args.push('-f', params.formatSelector || 'ba/b', '-x', '--audio-format', 'm4a');
        } else {
          args.push(
            '-f',
            params.formatSelector || 'bv*+ba/b',
            '--merge-output-format',
            'mp4',
          );
        }

        args.push(params.url);

        await new Promise<void>((resolve, reject) => {
          const child = spawn(ytDlpPath, args, { stdio: ['ignore', 'pipe', 'pipe'] });
          let stderr = '';
          let buffer = '';

          const handleLine = (line: string) => {
            const pctMatch = line.match(/\[download\]\s+(\d+(?:\.\d+)?)%/);
            if (pctMatch) {
              const pct = Math.min(99, Math.round(Number(pctMatch[1])));
              const speedMatch = line.match(/at\s+([^\s]+)\s+/);
              const etaMatch = line.match(/ETA\s+([^\s]+)/);
              job.stage = 'downloading';
              job.progress = pct;
              job.speed = speedMatch?.[1] || null;
              job.eta = etaMatch?.[1] || null;
              job.message = `Downloading high-quality stream (${pct}%)...`;
              emitJobUpdate(job);
            } else if (line.includes('[Merger]') || line.includes('[ExtractAudio]')) {
              job.stage = 'processing';
              job.progress = 96;
              job.speed = null;
              job.eta = null;
              job.message = 'Muxing video and audio tracks...';
              emitJobUpdate(job);
            }
          };

          child.stdout.on('data', (chunk: Buffer) => {
            buffer += chunk.toString();
            const lines = buffer.split(/\r?\n/);
            buffer = lines.pop() || '';
            for (const line of lines) handleLine(line);
          });
          child.stderr.on('data', (chunk: Buffer) => {
            stderr += chunk.toString();
          });
          child.on('error', reject);
          child.on('close', (code) => {
            if (buffer) handleLine(buffer);
            if (code === 0) resolve();
            else reject(new Error(formatYtDlpError(stderr)));
          });
        });
      });

      const files = await fsp.readdir(job.dir);
      const found = files.find((f) => f.startsWith('raw_media.') && !f.endsWith('.part'));
      if (found) {
        downloadedFile = path.join(job.dir, found);
      }
    }

    // Direct URL or HLS stream download fallback via ffmpeg
    if (!downloadedFile) {
      job.stage = 'downloading';
      job.progress = 10;
      job.message = 'Downloading direct video stream...';
      emitJobUpdate(job);

      const directTarget = path.join(job.dir, params.isAudioOnly ? 'raw_media.m4a' : 'raw_media.mp4');
      const ffArgs = params.isAudioOnly
        ? ['-y', '-i', params.url, '-vn', '-c:a', 'aac', '-b:a', '192k', directTarget]
        : ['-y', '-i', params.url, '-c', 'copy', '-movflags', '+faststart', directTarget];

      const res = await runCommand('ffmpeg', ffArgs, 180000);
      if (res.code !== 0) {
        throw new Error('Failed to download direct media stream.');
      }
      downloadedFile = directTarget;
    }

    const probe = await runFfprobeLocal(downloadedFile);
    job.width = probe.width;
    job.height = probe.height;
    job.duration = probe.duration;

    let finalPath = downloadedFile;
    let finalExt = params.isAudioOnly ? 'm4a' : 'mp4';

    if (!params.isAudioOnly && params.galleryCompatible) {
      job.stage = 'processing';
      job.progress = 15;
      job.speed = null;
      job.eta = null;

      const vcodec = (probe.vcodec || '').toLowerCase();
      const acodec = (probe.acodec || '').toLowerCase();
      const isAlreadyGallerySafe =
        downloadedFile.toLowerCase().endsWith('.mp4') &&
        (vcodec === 'h264' || vcodec === 'avc1') &&
        (!acodec || acodec === 'aac');

      const optimizedPath = path.join(job.dir, 'gallery_ready.mp4');
      job.message = isAlreadyGallerySafe
        ? 'Applying fast-start MP4 atoms for instant gallery import...'
        : 'Converting to Gallery-Ready H.264 + AAC MP4...';
      emitJobUpdate(job);

      await runFfmpegOptimize(
        job,
        downloadedFile,
        optimizedPath,
        !isAlreadyGallerySafe,
        probe.duration,
      );
      finalPath = optimizedPath;
      finalExt = 'mp4';
    } else if (!params.isAudioOnly) {
      finalExt = path.extname(downloadedFile).replace('.', '') || 'mp4';
    }

    const finalProbe = await runFfprobeLocal(finalPath);
    const stat = await fsp.stat(finalPath);

    job.filePath = finalPath;
    job.filename = sanitizeFilename(
      `${params.title}_${params.heightLabel || (finalProbe.height ? `${finalProbe.height}p` : 'HD')}`,
      finalExt,
    );
    job.mimeType = params.isAudioOnly
      ? 'audio/mp4'
      : finalExt === 'webm'
        ? 'video/webm'
        : 'video/mp4';
    job.fileSize = stat.size;
    job.width = finalProbe.width ?? job.width;
    job.height = finalProbe.height ?? job.height;
    job.vcodec = finalProbe.vcodec;
    job.acodec = finalProbe.acodec;
    job.duration = finalProbe.duration ?? job.duration;
    job.stage = 'completed';
    job.progress = 100;
    job.speed = null;
    job.eta = null;
    job.message = 'Ready to save directly to your device gallery.';
    emitJobUpdate(job);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Download failed.';
    job.stage = 'error';
    job.error = message;
    job.message = message;
    emitJobUpdate(job);
  }
}

async function startServer() {
  await fsp.mkdir(JOBS_ROOT, { recursive: true });

  // Clean up stale jobs older than 30 minutes
  setInterval(() => {
    const now = Date.now();
    for (const [id, job] of jobs.entries()) {
      if (now - job.createdAt > 30 * 60 * 1000 && job.listeners.size === 0) {
        jobs.delete(id);
        fsp.rm(job.dir, { recursive: true, force: true }).catch(() => {});
      }
    }
  }, 5 * 60 * 1000).unref();

  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', async (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  app.post('/api/inspect', async (req: Request, res: Response) => {
    try {
      const { url, cookies } = req.body as { url?: string; cookies?: string };
      if (!url || typeof url !== 'string') {
        res.status(400).json({ error: 'Please paste a valid social media or video URL.' });
        return;
      }

      const parsedUrl = validatePublicUrl(url);
      const targetUrl = parsedUrl.toString();

      // Fast-path direct media files (.mp4, .mov, .webm, .m4v, .m3u8)
      if (/\.(mp4|mov|webm|m4v|m3u8)(\?.*)?$/i.test(parsedUrl.pathname)) {
        const directFast = await probeMediaUrlWithFfprobe(targetUrl).catch(() => null);
        if (directFast) {
          res.json(directFast);
          return;
        }
      }

      const ytDlpPath = await resolveYtDlpPath();

      const inspectWithYtDlp = async (extraArgs: string[] = []): Promise<RawYtDlpInfo> => {
        return withTempCookiesFile(cookies, async (cookiePath) => {
          const args = [
            '--dump-single-json',
            '--no-playlist',
            '--no-warnings',
            '--socket-timeout',
            '15',
            ...extraArgs,
          ];
          if (cookiePath) {
            args.push('--cookies', cookiePath);
          }
          args.push(targetUrl);

          const { code, stdout, stderr } = await runCommand(ytDlpPath, args, 45000);
          if (code !== 0 || !stdout.trim()) {
            throw new Error(formatYtDlpError(stderr));
          }
          const raw = JSON.parse(stdout) as RawYtDlpInfo;
          if (raw.entries && raw.entries.length > 0) {
            return raw.entries[0];
          }
          return raw;
        });
      };

      let info: RawYtDlpInfo | null = null;
      let primaryError: Error | null = null;

      try {
        info = await inspectWithYtDlp();
      } catch (err) {
        primaryError = err instanceof Error ? err : new Error('Inspection failed.');
      }

      // Fallback 1: direct media stream via ffprobe
      if (!info) {
        const directMedia = await probeMediaUrlWithFfprobe(targetUrl).catch(() => null);
        if (directMedia) {
          res.json(directMedia);
          return;
        }
      }

      // Fallback 2: OpenGraph / HTML <video> tag extraction
      if (!info) {
        const ogVideoUrl = await tryExtractOpenGraphVideo(targetUrl);
        if (ogVideoUrl && ogVideoUrl !== targetUrl) {
          try {
            validatePublicUrl(ogVideoUrl);
            const ogMedia = await probeMediaUrlWithFfprobe(ogVideoUrl);
            if (ogMedia) {
              ogMedia.webpageUrl = targetUrl;
              ogMedia.platform = detectPlatformName(undefined, targetUrl);
              res.json(ogMedia);
              return;
            }
          } catch {
            // ignore fallback failure
          }
        }
      }

      if (!info) {
        res.status(422).json({
          error: primaryError?.message || 'Unable to inspect video at this URL.',
        });
        return;
      }

      const formats = buildQualityOptions(info);
      const result: InspectedMedia = {
        title: info.title?.trim() || 'Untitled Social Video',
        author: info.uploader || info.channel || info.uploader_id || 'Creator',
        platform: detectPlatformName(info.extractor_key || info.extractor, targetUrl),
        duration: typeof info.duration === 'number' ? info.duration : null,
        thumbnailUrl: info.thumbnail || null,
        webpageUrl: info.webpage_url || targetUrl,
        width: info.width || formats[0]?.width || null,
        height: info.height || formats[0]?.height || null,
        formats,
        isDirectMedia: false,
      };

      res.json(result);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Invalid URL or inspection failure.';
      res.status(400).json({ error: msg });
    }
  });

  app.get('/api/thumbnail', async (req: Request, res: Response) => {
    try {
      const rawUrl = req.query.url;
      if (typeof rawUrl !== 'string' || !rawUrl) {
        res.status(400).end();
        return;
      }
      const parsed = validatePublicUrl(rawUrl);
      const upstream = await fetch(parsed.toString(), {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
          Referer: `${parsed.protocol}//${parsed.host}/`,
        },
      });
      if (!upstream.ok) {
        res.status(404).end();
        return;
      }
      const contentType = upstream.headers.get('content-type') || 'image/jpeg';
      if (!contentType.startsWith('image/')) {
        res.status(415).end();
        return;
      }
      res.setHeader('Content-Type', contentType);
      res.setHeader('Cache-Control', 'public, max-age=3600');
      const buf = Buffer.from(await upstream.arrayBuffer());
      res.send(buf);
    } catch {
      res.status(404).end();
    }
  });

  app.post('/api/download', async (req: Request, res: Response) => {
    try {
      const {
        url,
        formatSelector,
        isAudioOnly = false,
        galleryCompatible = true,
        title = 'Social_Video',
        heightLabel = 'HD',
        cookies,
        isDirectMedia = false,
      } = req.body as {
        url?: string;
        formatSelector?: string;
        isAudioOnly?: boolean;
        galleryCompatible?: boolean;
        title?: string;
        heightLabel?: string;
        cookies?: string;
        isDirectMedia?: boolean;
      };

      if (!url || typeof url !== 'string') {
        res.status(400).json({ error: 'Missing media URL.' });
        return;
      }
      const parsedUrl = validatePublicUrl(url);

      const jobId = crypto.randomUUID();
      const job: InternalJob = {
        jobId,
        stage: 'queued',
        progress: 0,
        speed: null,
        eta: null,
        message: 'Queued for download...',
        error: null,
        filename: null,
        mimeType: null,
        fileSize: null,
        width: null,
        height: null,
        vcodec: null,
        acodec: null,
        duration: null,
        dir: path.join(JOBS_ROOT, jobId),
        filePath: null,
        createdAt: Date.now(),
        listeners: new Set(),
      };
      jobs.set(jobId, job);

      void processDownloadJob(job, {
        url: parsedUrl.toString(),
        formatSelector: formatSelector || 'bv*+ba/b',
        isAudioOnly: Boolean(isAudioOnly),
        galleryCompatible: Boolean(galleryCompatible),
        title,
        heightLabel,
        cookies,
        isDirectMedia: Boolean(isDirectMedia),
      });

      res.json({ jobId });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to start download.';
      res.status(400).json({ error: msg });
    }
  });

  app.get('/api/jobs/:id', (req: Request, res: Response) => {
    const job = jobs.get(req.params.id);
    if (!job) {
      res.status(404).json({ error: 'Download job not found.' });
      return;
    }
    res.json({
      jobId: job.jobId,
      stage: job.stage,
      progress: job.progress,
      speed: job.speed,
      eta: job.eta,
      message: job.message,
      error: job.error,
      filename: job.filename,
      mimeType: job.mimeType,
      fileSize: job.fileSize,
      width: job.width,
      height: job.height,
      vcodec: job.vcodec,
      acodec: job.acodec,
      duration: job.duration,
    });
  });

  app.get('/api/jobs/:id/events', (req: Request, res: Response) => {
    const job = jobs.get(req.params.id);
    if (!job) {
      res.status(404).end();
      return;
    }

    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    });

    job.listeners.add(res);
    emitJobUpdate(job);

    req.on('close', () => {
      job.listeners.delete(res);
    });
  });

  app.get('/api/jobs/:id/file', async (req: Request, res: Response) => {
    const job = jobs.get(req.params.id);
    if (!job || !job.filePath || !fs.existsSync(job.filePath)) {
      res.status(404).json({ error: 'Media file is no longer available.' });
      return;
    }

    const stat = await fsp.stat(job.filePath);
    const total = stat.size;
    const mimeType = job.mimeType || 'video/mp4';
    const filename = job.filename || 'FrameVault_Video.mp4';

    if (req.query.download === '1') {
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    } else {
      res.setHeader('Content-Disposition', `inline; filename="${filename}"`);
    }
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Content-Type', mimeType);

    const range = req.headers.range;
    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : total - 1;
      if (isNaN(start) || start >= total) {
        res.status(416).setHeader('Content-Range', `bytes */${total}`).end();
        return;
      }
      const chunkEnd = Math.min(end, total - 1);
      res.status(206);
      res.setHeader('Content-Range', `bytes ${start}-${chunkEnd}/${total}`);
      res.setHeader('Content-Length', String(chunkEnd - start + 1));
      fs.createReadStream(job.filePath, { start, end: chunkEnd }).pipe(res);
      return;
    }

    res.setHeader('Content-Length', String(total));
    fs.createReadStream(job.filePath).pipe(res);
  });

  app.delete('/api/jobs/:id', async (req: Request, res: Response) => {
    const job = jobs.get(req.params.id);
    if (job) {
      jobs.delete(req.params.id);
      await fsp.rm(job.dir, { recursive: true, force: true }).catch(() => {});
    }
    res.json({ ok: true });
  });

  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FrameVault server listening on http://0.0.0.0:${PORT}`);
  });
}

void startServer();
