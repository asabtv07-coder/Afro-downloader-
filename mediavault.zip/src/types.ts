export interface QualityOption {
  id: string;
  label: string;
  sublabel: string;
  height: number;
  width: number;
  fps: number | null;
  ext: string;
  vcodec: string;
  acodec: string;
  filesizeApprox: number | null;
  formatSelector: string;
  isAudioOnly: boolean;
}

export interface InspectedMedia {
  title: string;
  author: string;
  platform: string;
  duration: number | null;
  thumbnailUrl: string | null;
  webpageUrl: string;
  width: number | null;
  height: number | null;
  formats: QualityOption[];
  isDirectMedia: boolean;
}

export type DownloadStage =
  | 'queued'
  | 'extracting'
  | 'downloading'
  | 'processing'
  | 'completed'
  | 'error';

export interface DownloadJobStatus {
  jobId: string;
  stage: DownloadStage;
  progress: number;
  speed: string | null;
  eta: string | null;
  message: string;
  error: string | null;
  filename: string | null;
  mimeType: string | null;
  fileSize: number | null;
  width: number | null;
  height: number | null;
  vcodec: string | null;
  acodec: string | null;
  duration: number | null;
}

export interface GalleryItem {
  id: string;
  title: string;
  author: string;
  platform: string;
  sourceUrl: string;
  filename: string;
  mimeType: string;
  fileSize: number;
  width: number | null;
  height: number | null;
  duration: number | null;
  vcodec: string | null;
  acodec: string | null;
  isAudioOnly: boolean;
  thumbnailDataUrl: string | null;
  createdAt: number;
  blob: Blob;
}
