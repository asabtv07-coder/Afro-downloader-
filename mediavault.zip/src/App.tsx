import { useEffect, useState } from 'react';
import type { GalleryItem } from './types.ts';
import { deleteGalleryItem, listGalleryItems } from './lib/galleryDb.ts';
import { Header } from './components/Header.tsx';
import { CaptureWorkspace } from './components/CaptureWorkspace.tsx';
import { GalleryVault } from './components/GalleryVault.tsx';
import { SupportedPlatformsSection } from './components/SupportedPlatformsSection.tsx';
import { GalleryGuideSection } from './components/GalleryGuideSection.tsx';
import { MediaLightbox } from './components/MediaLightbox.tsx';

export default function App() {
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);
  const [loadingGallery, setLoadingGallery] = useState(true);
  const [activeLightboxItem, setActiveLightboxItem] = useState<GalleryItem | null>(null);

  useEffect(() => {
    let active = true;
    listGalleryItems()
      .then((items) => {
        if (active) setGalleryItems(items);
      })
      .catch(() => {
        // ignore indexeddb init error
      })
      .finally(() => {
        if (active) setLoadingGallery(false);
      });
    return () => {
      active = false;
    };
  }, []);

  function handleNavigate(sectionId: string) {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  function handleMediaSaved(item: GalleryItem) {
    setGalleryItems((prev) => [item, ...prev.filter((existing) => existing.id !== item.id)]);
  }

  async function handleDeleteItem(id: string) {
    setGalleryItems((prev) => prev.filter((item) => item.id !== id));
    await deleteGalleryItem(id).catch(() => {});
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA] text-zinc-950 flex flex-col">
      <Header galleryCount={galleryItems.length} onNavigate={handleNavigate} />

      <main className="flex-1">
        <CaptureWorkspace
          onMediaSaved={handleMediaSaved}
          onOpenLightbox={setActiveLightboxItem}
        />

        <GalleryVault
          items={galleryItems}
          loading={loadingGallery}
          onSelectItem={setActiveLightboxItem}
          onDeleteItem={(id) => void handleDeleteItem(id)}
          onScrollToCapture={() => handleNavigate('capture')}
        />

        <SupportedPlatformsSection />

        <GalleryGuideSection />
      </main>

      <footer className="border-t border-zinc-200 bg-white">
        <div className="max-w-6xl mx-auto px-6 py-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-zinc-500">
          <span className="font-display font-semibold text-zinc-900">FrameVault</span>
          <span>
            Local media stays in your browser&apos;s IndexedDB vault. Save only content you own or have permission to download.
          </span>
        </div>
      </footer>

      <MediaLightbox
        item={activeLightboxItem}
        onClose={() => setActiveLightboxItem(null)}
        onDelete={(id) => void handleDeleteItem(id)}
      />
    </div>
  );
}
