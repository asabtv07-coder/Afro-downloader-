import { useEffect, useRef, useState } from 'react';
import {
  Check,
  ClipboardPaste,
  Download,
  Film,
  KeyRound,
  Loader2,
  Play,
  Share2,
  ShieldCheck,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import type {
  DownloadJobStatus,
  GalleryItem,
  InspectedMedia,
  QualityOption,
} from '../types.ts';
import { formatBytes, formatDuration } from '../lib/formatters.ts';
import { captureThumbnailFromBlob, saveGalleryItem } from '../lib/galleryDb.ts';
import {
  canShareToPhotos,
  saveToDeviceDisk,
  shareToDevicePhotos,
} from '../lib/saveToGallery.ts';

interface CaptureWorkspaceProps {
  onMediaSaved: (item: GalleryItem) => void;
  onOpenLightbox: (item: GalleryItem) => void;
}

const SAMPLE_LINKS = [
  {
    label: 'Sample Sintel Trailer (MP4)',
    url: 'https://media.w3.org/2010/05/sintel/trailer.mp4',
  },
  {
    label: 'Sample Bunny Trailer (MP4)',
    url: 'https://media.w3.org/2010/05/bunny/trailer.mp4',
  },
];

export function CaptureWorkspace({
  onMediaSaved,
  onOpenLightbox,
}: CaptureWorkspaceProps) {
  const [url, setUrl] = useState('');
  const [cookies, setCookies] = useState('');
  const [showCookies, setShowCookies] = useState(false);

  const [inspecting, setInspecting] = useState(false);
  const [inspectError, setInspectError] = useState<string | null>(null);
  const [media, setMedia] = useState<InspectedMedia | null>(null);
  const [thumbnailFailed, setThumbnailFailed] = useState(false);

  const [selectedFormat, setSelectedFormat] = useState<QualityOption | null>(null);
  const [galleryCompatible, setGalleryCompatible] = useState(true);

  const [job, setJob] = useState<DownloadJobStatus | null>(null);
  const [savedItem, setSavedItem] = useState<GalleryItem | null>(null);
  const [exportFeedback, setExportFeedback] = useState<string | null>(null);
  const [downloadingBlob, setDownloadingBlob] = useState(false);

  const eventSourceRef = useRef<EventSource | null>(null);
  const cookieInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    return () => {
      eventSourceRef.current?.close();
    };
  }, []);

  async function handleInspect(targetUrl?: string) {
    const urlToInspect = (targetUrl ?? url).trim();
    if (!urlToInspect) {
      setInspectError('Paste a social media video link or direct MP4 URL first.');
      return;
    }

    eventSourceRef.current?.close();
    setInspecting(true);
    setInspectError(null);
    setMedia(null);
    setSelectedFormat(null);
    setJob(null);
    setSavedItem(null);
    setExportFeedback(null);
    setThumbnailFailed(false);

    try {
      const resp = await fetch('/api/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: urlToInspect,
          cookies: cookies.trim() || undefined,
        }),
      });
      const data = (await resp.json()) as InspectedMedia & { error?: string };
      if (!resp.ok) {
        throw new Error(data.error || 'Could not inspect video link.');
      }
      setMedia(data);
      setSelectedFormat(data.formats[0] || null);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to inspect link.';
      setInspectError(message);
    } finally {
      setInspecting(false);
    }
  }

  async function handlePasteFromClipboard() {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setUrl(text.trim());
        setInspectError(null);
      }
    } catch {
      setInspectError('Clipboard access was blocked by the browser. Paste directly into the box.');
    }
  }

  function handleCookieFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setCookies(reader.result);
      }
    };
    reader.readAsText(file);
  }

  async function finalizeCompletedJob(completedJob: DownloadJobStatus, inspected: InspectedMedia, chosen: QualityOption) {
    setDownloadingBlob(true);
    try {
      const fileResp = await fetch(`/api/jobs/${completedJob.jobId}/file`);
      if (!fileResp.ok) {
        throw new Error('Could not retrieve processed video file.');
      }
      const blob = await fileResp.blob();

      let thumbDataUrl: string | null = null;
      if (!chosen.isAudioOnly) {
        thumbDataUrl = await captureThumbnailFromBlob(blob);
      }
      if (!thumbDataUrl && inspected.thumbnailUrl && !thumbnailFailed) {
        try {
          const thumbResp = await fetch(
            `/api/thumbnail?url=${encodeURIComponent(inspected.thumbnailUrl)}`,
          );
          if (thumbResp.ok) {
            const thumbBlob = await thumbResp.blob();
            thumbDataUrl = await new Promise<string>((resolve) => {
              const r = new FileReader();
              r.onloadend = () => resolve(typeof r.result === 'string' ? r.result : '');
              r.readAsDataURL(thumbBlob);
            });
          }
        } catch {
          // ignore thumbnail cache error
        }
      }

      const item: GalleryItem = {
        id: completedJob.jobId,
        title: inspected.title,
        author: inspected.author,
        platform: inspected.platform,
        sourceUrl: inspected.webpageUrl,
        filename: completedJob.filename || 'FrameVault_Video.mp4',
        mimeType: completedJob.mimeType || blob.type || 'video/mp4',
        fileSize: completedJob.fileSize || blob.size,
        width: completedJob.width ?? chosen.width ?? null,
        height: completedJob.height ?? (chosen.height || null),
        duration: completedJob.duration ?? inspected.duration ?? null,
        vcodec: completedJob.vcodec ?? (chosen.isAudioOnly ? 'none' : chosen.vcodec),
        acodec: completedJob.acodec ?? chosen.acodec,
        isAudioOnly: chosen.isAudioOnly,
        thumbnailDataUrl: thumbDataUrl || null,
        createdAt: Date.now(),
        blob,
      };

      await saveGalleryItem(item);
      setSavedItem(item);
      onMediaSaved(item);
      setExportFeedback('Saved to your FrameVault Gallery. Ready to export to your device photos.');

      // Clean up server temp job now that the file is persisted in IndexedDB
      void fetch(`/api/jobs/${completedJob.jobId}`, { method: 'DELETE' }).catch(() => {});
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to store video in local gallery.';
      setJob((prev) => (prev ? { ...prev, stage: 'error', error: msg, message: msg } : prev));
    } finally {
      setDownloadingBlob(false);
    }
  }

  async function handleStartDownload() {
    if (!media || !selectedFormat) return;
    eventSourceRef.current?.close();
    setSavedItem(null);
    setExportFeedback(null);

    const initialJob: DownloadJobStatus = {
      jobId: '',
      stage: 'queued',
      progress: 0,
      speed: null,
      eta: null,
      message: 'Starting download pipeline...',
      error: null,
      filename: null,
      mimeType: null,
      fileSize: null,
      width: null,
      height: null,
      vcodec: null,
      acodec: null,
      duration: null,
    };
    setJob(initialJob);

    try {
      const resp = await fetch('/api/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: media.webpageUrl,
          formatSelector: selectedFormat.formatSelector,
          isAudioOnly: selectedFormat.isAudioOnly,
          galleryCompatible,
          title: media.title,
          heightLabel: selectedFormat.isAudioOnly ? 'Audio' : `${selectedFormat.height}p`,
          cookies: cookies.trim() || undefined,
          isDirectMedia: media.isDirectMedia,
        }),
      });
      const data = (await resp.json()) as { jobId?: string; error?: string };
      if (!resp.ok || !data.jobId) {
        throw new Error(data.error || 'Failed to start download.');
      }

      const jobId = data.jobId;
      let finalized = false;

      const handleUpdate = (status: DownloadJobStatus) => {
        setJob(status);
        if (status.stage === 'completed' && !finalized) {
          finalized = true;
          eventSourceRef.current?.close();
          void finalizeCompletedJob(status, media, selectedFormat);
        } else if (status.stage === 'error') {
          eventSourceRef.current?.close();
        }
      };

      const es = new EventSource(`/api/jobs/${jobId}/events`);
      eventSourceRef.current = es;
      es.onmessage = (event) => {
        try {
          const parsed = JSON.parse(event.data) as DownloadJobStatus;
          handleUpdate(parsed);
        } catch {
          // ignore malformed event
        }
      };
      es.onerror = () => {
        es.close();
        // Fallback polling if SSE disconnects
        const pollTimer = window.setInterval(async () => {
          if (finalized) {
            window.clearInterval(pollTimer);
            return;
          }
          try {
            const pollResp = await fetch(`/api/jobs/${jobId}`);
            if (!pollResp.ok) {
              window.clearInterval(pollTimer);
              return;
            }
            const status = (await pollResp.json()) as DownloadJobStatus;
            handleUpdate(status);
            if (status.stage === 'completed' || status.stage === 'error') {
              window.clearInterval(pollTimer);
            }
          } catch {
            window.clearInterval(pollTimer);
          }
        }, 1000);
      };
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Download failed.';
      setJob({
        ...initialJob,
        stage: 'error',
        error: msg,
        message: msg,
      });
    }
  }

  async function handleSharePhotos() {
    if (!savedItem) return;
    const outcome = await shareToDevicePhotos(
      savedItem.blob,
      savedItem.filename,
      savedItem.title,
    );
    if (outcome === 'shared') {
      setExportFeedback('Opened native share sheet — choose "Save Video" to store in Photos.');
    } else if (outcome === 'unsupported') {
      const diskRes = await saveToDeviceDisk(savedItem.blob, savedItem.filename);
      if (diskRes !== 'cancelled') {
        setExportFeedback('Saved MP4 directly to your device storage.');
      }
    }
  }

  async function handleDirectSave() {
    if (!savedItem) return;
    const outcome = await saveToDeviceDisk(savedItem.blob, savedItem.filename);
    if (outcome === 'saved-picker') {
      setExportFeedback(`Saved "${savedItem.filename}" to your chosen folder.`);
    } else if (outcome === 'downloaded') {
      setExportFeedback(`Downloaded "${savedItem.filename}" to your device.`);
    }
  }

  const isBusy =
    Boolean(job && job.stage !== 'completed' && job.stage !== 'error') || downloadingBlob;
  const shareSupported = savedItem
    ? canShareToPhotos(savedItem.mimeType, savedItem.filename)
    : false;

  return (
    <section id="capture" className="max-w-6xl mx-auto px-6 pt-12 pb-16 md:pt-16 md:pb-20">
      <div className="max-w-3xl">
        <p className="text-sm font-medium text-[#E11D48] mb-3">
          High-Definition Social Video Capture
        </p>
        <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-zinc-950 leading-[1.06] [text-wrap:balance]">
          Download social videos straight to your gallery
        </h1>
        <p className="mt-4 text-base md:text-lg text-zinc-600 leading-relaxed max-w-2xl">
          Extract up to 4K and 1080p streams from TikTok, Instagram, YouTube, X, and Reddit, automatically remuxed into gallery-ready H.264 MP4 for instant Photos and Camera Roll saving.
        </p>
      </div>

      {/* URL Capture Bar */}
      <div className="mt-8 bg-white border border-zinc-200 rounded-2xl p-4 sm:p-5">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void handleInspect();
          }}
          className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3"
        >
          <div className="relative flex-1 flex items-center">
            <input
              type="url"
              value={url}
              onChange={(e) => {
                setUrl(e.target.value);
                if (inspectError) setInspectError(null);
              }}
              placeholder="Paste a TikTok, Instagram Reel, YouTube, X, or MP4 link..."
              aria-label="Social media video URL"
              className="w-full h-12 pl-4 pr-24 rounded-xl bg-[#FAFAFA] border border-zinc-200 text-zinc-950 placeholder:text-zinc-400 text-sm md:text-base focus:outline-none focus:border-zinc-950 focus:bg-white transition-colors"
            />
            <div className="absolute right-2 flex items-center gap-1">
              {url ? (
                <button
                  type="button"
                  onClick={() => {
                    setUrl('');
                    setInspectError(null);
                  }}
                  aria-label="Clear URL"
                  className="p-2 text-zinc-400 hover:text-zinc-700 rounded-lg transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              ) : null}
              <button
                type="button"
                onClick={() => void handlePasteFromClipboard()}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-zinc-700 hover:text-zinc-950 bg-white border border-zinc-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <ClipboardPaste className="w-3.5 h-3.5" />
                <span>Paste</span>
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={inspecting || isBusy}
            className="h-12 px-6 rounded-xl bg-[#E11D48] hover:bg-[#BE123C] disabled:opacity-60 text-white font-medium text-sm md:text-base transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D48] focus-visible:ring-offset-2"
          >
            {inspecting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Inspecting...</span>
              </>
            ) : (
              <span>Inspect Link</span>
            )}
          </button>
        </form>

        {/* Secondary Utility Row: Sample Links + Optional Session Cookies */}
        <div className="mt-4 pt-4 border-t border-zinc-100 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-zinc-500">
            <span>Try a sample stream:</span>
            {SAMPLE_LINKS.map((sample) => (
              <button
                key={sample.url}
                type="button"
                disabled={inspecting || isBusy}
                onClick={() => {
                  setUrl(sample.url);
                  void handleInspect(sample.url);
                }}
                className="font-medium text-zinc-800 hover:text-[#E11D48] underline underline-offset-4 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                {sample.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setShowCookies((v) => !v)}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-600 hover:text-zinc-950 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>
              {cookies.trim()
                ? 'Session Cookies Attached'
                : 'Session Cookies (Optional)'}
            </span>
          </button>
        </div>

        {/* Collapsible Session Cookies Panel */}
        {showCookies ? (
          <div className="mt-4 pt-4 border-t border-zinc-100">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
              <p className="text-xs text-zinc-600">
                Needed only for private posts or platforms requesting sign-in verification. Paste Netscape <code className="font-mono text-zinc-900">cookies.txt</code> content or upload a file; never stored on the server.
              </p>
              <div className="flex items-center gap-2">
                <input
                  ref={cookieInputRef}
                  type="file"
                  accept=".txt"
                  onChange={handleCookieFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => cookieInputRef.current?.click()}
                  className="px-3 py-1.5 text-xs font-medium text-zinc-700 bg-zinc-100 hover:bg-zinc-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Upload cookies.txt
                </button>
                {cookies.trim() ? (
                  <button
                    type="button"
                    onClick={() => setCookies('')}
                    className="px-3 py-1.5 text-xs font-medium text-zinc-600 hover:text-zinc-950 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    Clear
                  </button>
                ) : null}
              </div>
            </div>
            <textarea
              value={cookies}
              onChange={(e) => setCookies(e.target.value)}
              rows={3}
              placeholder="# Netscape HTTP Cookie File..."
              className="w-full p-3 rounded-xl bg-[#FAFAFA] border border-zinc-200 font-mono text-xs text-zinc-800 placeholder:text-zinc-400 focus:outline-none focus:border-zinc-950"
            />
          </div>
        ) : null}
      </div>

      {/* Inspection Error */}
      {inspectError ? (
        <div
          role="alert"
          className="mt-5 p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800 flex items-start justify-between gap-4"
        >
          <div>
            <p className="font-semibold text-red-950">Inspection Error</p>
            <p className="mt-0.5 text-red-800">{inspectError}</p>
          </div>
          <button
            type="button"
            onClick={() => setInspectError(null)}
            aria-label="Dismiss error"
            className="p-1 text-red-600 hover:text-red-900 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : null}

      {/* Inspected Media & Quality Matrix */}
      {media ? (
        <div className="mt-8 bg-white border border-zinc-200 rounded-2xl p-6 md:p-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Preview Column */}
            <div className="lg:col-span-5">
              <div className="relative aspect-video w-full rounded-xl overflow-hidden bg-zinc-900 border border-zinc-200">
                {media.thumbnailUrl && !thumbnailFailed ? (
                  <img
                    src={`/api/thumbnail?url=${encodeURIComponent(media.thumbnailUrl)}`}
                    alt={media.title}
                    referrerPolicy="no-referrer"
                    onError={() => setThumbnailFailed(true)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-zinc-900 via-zinc-800 to-zinc-900 text-zinc-300 p-6 text-center">
                    <Film className="w-9 h-9 text-zinc-400 mb-3" />
                    <p className="text-xs font-mono text-zinc-400 truncate max-w-full">
                      {media.platform}
                    </p>
                    <p className="mt-1 text-sm font-medium text-zinc-100 line-clamp-2">
                      {media.title}
                    </p>
                  </div>
                )}

                {media.duration ? (
                  <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/80 via-black/35 to-transparent flex items-end justify-between">
                    <span className="text-xs font-mono text-white/90 tabular-nums">
                      {media.width && media.height ? `${media.width}×${media.height}` : 'HD Stream'}
                    </span>
                    <span className="text-xs font-mono font-medium text-white tabular-nums">
                      {formatDuration(media.duration)}
                    </span>
                  </div>
                ) : null}
              </div>

              <div className="mt-4">
                <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500">
                  <span className="font-medium text-zinc-800">{media.platform}</span>
                  <span aria-hidden="true">·</span>
                  <span className="truncate max-w-[200px]">{media.author}</span>
                  {media.duration ? (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {formatDuration(media.duration)}
                      </span>
                    </>
                  ) : null}
                </div>
                <h2 className="mt-1.5 font-display text-xl font-semibold text-zinc-950 leading-snug">
                  {media.title}
                </h2>
              </div>
            </div>

            {/* Quality Selection & Export Column */}
            <div className="lg:col-span-7">
              <div className="flex items-center justify-between gap-4 pb-3 border-b border-zinc-100">
                <div className="flex items-center gap-2 text-sm font-semibold text-zinc-950">
                  <SlidersHorizontal className="w-4 h-4 text-zinc-500" />
                  <span>Select Quality &amp; Format</span>
                </div>
                <span className="text-xs text-zinc-500 tabular-nums">
                  {media.formats.length} stream{media.formats.length === 1 ? '' : 's'} detected
                </span>
              </div>

              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {media.formats.map((opt) => {
                  const isSelected = selectedFormat?.id === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      disabled={isBusy}
                      onClick={() => setSelectedFormat(opt)}
                      className={`text-left p-3.5 rounded-xl border transition-colors cursor-pointer disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D48] ${
                        isSelected
                          ? 'border-[#E11D48] bg-[#E11D48]/[0.04]'
                          : 'border-zinc-200 hover:border-zinc-300 bg-[#FAFAFA]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-display text-base font-semibold text-zinc-950">
                          {opt.label}
                        </span>
                        <span className="text-xs font-mono text-zinc-600 tabular-nums">
                          {opt.filesizeApprox ? `~${formatBytes(opt.filesizeApprox)}` : opt.ext.toUpperCase()}
                        </span>
                      </div>
                      <div className="mt-1 flex items-center gap-1.5 text-xs text-zinc-500">
                        <span>{opt.sublabel}</span>
                        {opt.fps && opt.fps > 30 ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono tabular-nums">{opt.fps}fps</span>
                          </>
                        ) : null}
                        <span aria-hidden="true">·</span>
                        <span className="font-mono uppercase">{opt.ext}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Gallery Compatibility Toggle */}
              {!selectedFormat?.isAudioOnly ? (
                <div className="mt-5 pt-5 border-t border-zinc-100 flex items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-sm font-medium text-zinc-950">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>Gallery-Ready H.264 + AAC MP4</span>
                    </div>
                    <p className="mt-0.5 text-xs text-zinc-500">
                      Automatically converts VP9/AV1 or WebM streams so iOS Photos &amp; Android Gallery import cleanly.
                    </p>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={galleryCompatible}
                    disabled={isBusy}
                    onClick={() => setGalleryCompatible((v) => !v)}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D48] ${
                      galleryCompatible ? 'bg-zinc-950' : 'bg-zinc-300'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                        galleryCompatible ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              ) : null}

              {/* Primary Download Button & Progress */}
              <div className="mt-6">
                {!savedItem ? (
                  <button
                    type="button"
                    disabled={!selectedFormat || isBusy}
                    onClick={() => void handleStartDownload()}
                    className="w-full h-12 px-6 rounded-xl bg-[#E11D48] hover:bg-[#BE123C] disabled:opacity-60 text-white font-medium text-sm md:text-base transition-colors inline-flex items-center justify-center gap-2 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D48] focus-visible:ring-offset-2"
                  >
                    {isBusy ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>
                          {downloadingBlob
                            ? 'Saving to local gallery...'
                            : job?.stage === 'processing'
                              ? 'Optimizing MP4 for gallery...'
                              : 'Downloading stream...'}
                        </span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        <span>
                          Download {selectedFormat?.label} &amp; Save to Gallery
                        </span>
                      </>
                    )}
                  </button>
                ) : null}

                {/* Real-time Progress Readout */}
                {job && job.stage !== 'completed' && job.stage !== 'error' ? (
                  <div className="mt-4">
                    <div className="flex items-center justify-between text-xs text-zinc-600 mb-1.5">
                      <span>{job.message}</span>
                      <span className="font-mono tabular-nums">
                        {job.progress}%
                        {job.speed ? ` · ${job.speed}` : ''}
                        {job.eta ? ` · ETA ${job.eta}` : ''}
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-zinc-100 overflow-hidden">
                      <div
                        className="h-full bg-[#E11D48] transition-all duration-200"
                        style={{ width: `${Math.max(4, job.progress)}%` }}
                      />
                    </div>
                  </div>
                ) : null}

                {job?.stage === 'error' ? (
                  <div
                    role="alert"
                    className="mt-4 p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800"
                  >
                    <span className="font-semibold text-red-950">Download failed: </span>
                    {job.error}
                  </div>
                ) : null}

                {/* Completed Direct Gallery Save Actions */}
                {savedItem ? (
                  <div className="mt-4 pt-4 border-t border-zinc-100">
                    <div className="flex items-center gap-2 text-sm font-semibold text-emerald-700">
                      <Check className="w-4 h-4" />
                      <span>Download Complete · {formatBytes(savedItem.fileSize)}</span>
                    </div>
                    {exportFeedback ? (
                      <p className="mt-1 text-xs text-zinc-600">{exportFeedback}</p>
                    ) : null}

                    <div className="mt-4 flex flex-wrap items-center gap-3">
                      {shareSupported ? (
                        <button
                          type="button"
                          onClick={() => void handleSharePhotos()}
                          className="h-11 px-5 rounded-xl bg-[#E11D48] hover:bg-[#BE123C] text-white text-sm font-medium inline-flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                        >
                          <Share2 className="w-4 h-4" />
                          <span>Save to Device Photos</span>
                        </button>
                      ) : null}

                      <button
                        type="button"
                        onClick={() => void handleDirectSave()}
                        className={`h-11 px-5 rounded-xl text-sm font-medium inline-flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                          shareSupported
                            ? 'bg-zinc-950 hover:bg-zinc-800 text-white'
                            : 'bg-[#E11D48] hover:bg-[#BE123C] text-white'
                        }`}
                      >
                        <Download className="w-4 h-4" />
                        <span>Save File to Device</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onOpenLightbox(savedItem)}
                        className="h-11 px-4 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-900 text-sm font-medium inline-flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                      >
                        <Play className="w-4 h-4" />
                        <span>Play in Lightbox</span>
                      </button>
                    </div>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}
