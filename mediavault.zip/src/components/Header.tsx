interface HeaderProps {
  galleryCount: number;
  onNavigate: (sectionId: string) => void;
}

export function Header({ galleryCount, onNavigate }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-[#FAFAFA]/92 backdrop-blur-md border-b border-zinc-200/80">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
        <a
          href="#capture"
          onClick={(e) => {
            e.preventDefault();
            onNavigate('capture');
          }}
          className="font-display text-xl font-bold tracking-tight text-zinc-950 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D48] rounded-sm"
        >
          FrameVault
        </a>

        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-zinc-600"
        >
          <a
            href="#capture"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('capture');
            }}
            className="hover:text-zinc-950 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Capture
          </a>
          <a
            href="#gallery"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('gallery');
            }}
            className="hover:text-zinc-950 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Gallery
          </a>
          <a
            href="#platforms"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('platforms');
            }}
            className="hover:text-zinc-950 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Platforms
          </a>
          <a
            href="#guide"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('guide');
            }}
            className="hover:text-zinc-950 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Gallery Guide
          </a>
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('gallery')}
            className="px-4 py-2 text-sm font-medium text-white bg-zinc-950 hover:bg-zinc-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D48] focus-visible:ring-offset-2"
          >
            <span className="tabular-nums">
              {galleryCount > 0 ? `Open Gallery (${galleryCount})` : 'Open Gallery'}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
