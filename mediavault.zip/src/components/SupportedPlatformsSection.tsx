const PLATFORMS = [
  {
    name: 'TikTok',
    detail: 'No-watermark vertical reels · 1080p MP4 · Original audio',
  },
  {
    name: 'Instagram Reels',
    detail: 'Reels, carousels & feed clips · H.264 MP4 · 60fps support',
  },
  {
    name: 'YouTube & Shorts',
    detail: 'Up to 4K 2160p UHD · Muxed video + AAC · M4A audio',
  },
  {
    name: 'X (Twitter)',
    detail: 'High-bitrate timeline clips · Multi-resolution streams',
  },
  {
    name: 'Reddit',
    detail: 'Auto-merges separate DASH video & audio tracks into MP4',
  },
  {
    name: 'Facebook & Watch',
    detail: 'HD reels & public clips · Fast-start mobile container',
  },
  {
    name: 'Threads & Bluesky',
    detail: 'Direct social feed video capture · Camera Roll ready',
  },
  {
    name: 'Vimeo',
    detail: 'High-bitrate showcase reels · Session cookie support',
  },
  {
    name: 'Direct MP4 & HLS',
    detail: 'Raw .mp4, .mov, .webm & .m3u8 streams · FFmpeg remux',
  },
];

export function SupportedPlatformsSection() {
  return (
    <section
      id="platforms"
      className="max-w-6xl mx-auto px-6 py-20 border-t border-zinc-200"
    >
      <div className="max-w-2xl mb-12">
        <p className="text-sm font-medium text-[#E11D48] mb-2">
          Supported Sources
        </p>
        <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight text-zinc-950 [text-wrap:balance]">
          Built for every major social video stream
        </h2>
        <p className="mt-3 text-base text-zinc-600 leading-relaxed">
          FrameVault resolves adaptive DASH and HLS streams, merges separate audio tracks, and delivers a single self-contained MP4 ready for your phone or desktop gallery.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-8">
        {PLATFORMS.map((item) => (
          <div
            key={item.name}
            className="pt-5 border-t border-zinc-200/80"
          >
            <h3 className="font-display text-lg font-semibold text-zinc-950">
              {item.name}
            </h3>
            <p className="mt-1.5 text-sm text-zinc-600 leading-relaxed">
              {item.detail}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
