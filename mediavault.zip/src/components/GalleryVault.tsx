import { useMemo, useState } from 'react';
import {
  Download,
  Film,
  Music,
  Play,
  Search,
  Share2,
  Trash2,
} from 'lucide-react';
import type { GalleryItem } from '../types.ts';
import {
  formatBytes,
  formatDuration,
  formatResolutionLabel,
  formatSavedDate,
} from '../lib/formatters.ts';
import {
  canShareToPhotos,
  saveToDeviceDisk,
  shareToDevicePhotos,
} from '../lib/saveToGallery.ts';

interface GalleryVaultProps {
  items: GalleryItem[];
  loading: boolean;
  onSelectItem: (item: GalleryItem) => void;
  onDeleteItem: (id: string) => void;
  onScrollToCapture: () => void;
}

type GalleryFilter = 'all' | 'hd' | 'sd' | 'audio';
type GallerySort = 'newest' | 'largest' | 'resolution';

export function GalleryVault({
  items,
  loading,
  onSelectItem,
  onDeleteItem,
  onScrollToCapture,
}: GalleryVaultProps) {
  const [filter, setFilter] = useState<GalleryFilter>('all');
  const [sortBy, setSortBy] = useState<GallerySort>('newest');
  const [query, setQuery] = useState('');
  const [actionStatus, setActionStatus] = useState<string | null>(null);

  const totalBytes = useMemo(
    () => items.reduce((acc, item) => acc + (item.fileSize || 0), 0),
    [items],
  );

  const filteredItems = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = items.filter((item) => {
      if (filter === 'hd' && (item.isAudioOnly || (item.height || 0) < 1080)) return false;
      if (filter === 'sd' && (item.isAudioOnly || (item.height || 0) >= 1080)) return false;
      if (filter === 'audio' && !item.isAudioOnly) return false;
      if (
        q &&
        !item.title.toLowerCase().includes(q) &&
        !item.platform.toLowerCase().includes(q) &&
        !item.author.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });

    if (sortBy === 'largest') {
      return [...list].sort((a, b) => b.fileSize - a.fileSize);
    }
    if (sortBy === 'resolution') {
      return [...list].sort((a, b) => (b.height || 0) - (a.height || 0));
    }
    return [...list].sort((a, b) => b.createdAt - a.createdAt);
  }, [items, filter, sortBy, query]);

  async function handleSaveToDevice(item: GalleryItem) {
    if (canShareToPhotos(item.mimeType, item.filename)) {
      const res = await shareToDevicePhotos(item.blob, item.filename, item.title);
      if (res === 'shared') {
        setActionStatus(`Opened share sheet for "${item.title}" — tap Save Video for Photos.`);
        return;
      }
    }
    const diskRes = await saveToDeviceDisk(item.blob, item.filename);
    if (diskRes !== 'cancelled') {
      setActionStatus(`Saved "${item.filename}" directly to your device.`);
    }
  }

  return (
    <section
      id="gallery"
      className="max-w-6xl mx-auto px-6 py-16 md:py-20 border-t border-zinc-200"
    >
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <p className="text-sm font-medium text-[#E11D48] mb-2">
            Offline Media Gallery
          </p>
          <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight text-zinc-950 [text-wrap:balance]">
            Saved Gallery Vault
          </h2>
          <p className="mt-2 text-sm md:text-base text-zinc-600 tabular-nums">
            {items.length} clip{items.length === 1 ? '' : 's'} stored locally in your browser · {formatBytes(totalBytes)} total
          </p>
        </div>

        {items.length > 0 ? (
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 p-1 bg-zinc-100 rounded-lg">
              {(
                [
                  { id: 'all', label: 'All' },
                  { id: 'hd', label: '1080p & 4K' },
                  { id: 'sd', label: '720p & SD' },
                  { id: 'audio', label: 'Audio' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilter(tab.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    filter === tab.id
                      ? 'bg-white text-zinc-950 shadow-xs'
                      : 'text-zinc-600 hover:text-zinc-950'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        ) : null}
      </div>

      {/* Search & Sort Controls when populated */}
      {items.length > 0 ? (
        <div className="mt-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search saved titles, creators, or platforms..."
              aria-label="Search saved gallery"
              className="w-full h-10 pl-10 pr-4 rounded-xl bg-white border border-zinc-200 text-sm text-zinc-950 placeholder:text-zinc-400 focus:outline-none focus:border-zinc-950"
            />
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <label htmlFor="gallery-sort" className="text-xs text-zinc-500">
              Sort
            </label>
            <select
              id="gallery-sort"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as GallerySort)}
              className="h-10 px-3 rounded-xl bg-white border border-zinc-200 text-xs font-medium text-zinc-800 focus:outline-none focus:border-zinc-950 cursor-pointer"
            >
              <option value="newest">Newest Saved</option>
              <option value="resolution">Highest Resolution</option>
              <option value="largest">Largest File Size</option>
            </select>
          </div>
        </div>
      ) : null}

      {actionStatus ? (
        <div className="mt-4 px-4 py-2.5 rounded-xl bg-zinc-900 text-white text-xs flex items-center justify-between gap-4">
          <span>{actionStatus}</span>
          <button
            type="button"
            onClick={() => setActionStatus(null)}
            className="text-zinc-300 hover:text-white cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      ) : null}

      {/* Loading State */}
      {loading ? (
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((n) => (
            <div
              key={n}
              className="rounded-2xl bg-white border border-zinc-200 overflow-hidden animate-pulse"
            >
              <div className="aspect-video bg-zinc-100" />
              <div className="p-4 space-y-2.5">
                <div className="h-4 w-3/4 bg-zinc-100 rounded" />
                <div className="h-3 w-1/2 bg-zinc-100 rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : items.length === 0 ? (
        /* Empty State */
        <div className="mt-8 rounded-2xl bg-white border border-zinc-200 p-10 md:p-14 text-center">
          <div className="w-12 h-12 rounded-2xl bg-zinc-100 text-zinc-700 flex items-center justify-center mx-auto mb-4">
            <Film className="w-6 h-6" />
          </div>
          <h3 className="font-display text-xl font-semibold text-zinc-950">
            Your media gallery is empty
          </h3>
          <p className="mt-2 text-sm text-zinc-600 max-w-md mx-auto leading-relaxed">
            Any social video you download is automatically stored here in high-definition MP4 for instant playback and one-tap export to your device Photos or Camera Roll.
          </p>
          <button
            type="button"
            onClick={onScrollToCapture}
            className="mt-6 h-11 px-5 rounded-xl bg-zinc-950 hover:bg-zinc-800 text-white text-sm font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Paste a Video Link
          </button>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="mt-8 rounded-2xl bg-white border border-zinc-200 p-10 text-center">
          <p className="text-sm text-zinc-600">
            No saved clips match your current filter or search query.
          </p>
          <button
            type="button"
            onClick={() => {
              setFilter('all');
              setQuery('');
            }}
            className="mt-4 px-4 py-2 text-xs font-medium text-zinc-900 bg-zinc-100 hover:bg-zinc-200 rounded-lg transition-colors cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        /* Media-First Gallery Grid */
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => {
            const resLabel = formatResolutionLabel(
              item.width,
              item.height,
              item.isAudioOnly,
            );
            const mobileShare = canShareToPhotos(item.mimeType, item.filename);

            return (
              <article
                key={item.id}
                className="group rounded-2xl bg-white border border-zinc-200 overflow-hidden flex flex-col"
              >
                <button
                  type="button"
                  onClick={() => onSelectItem(item)}
                  className="relative aspect-video w-full bg-zinc-900 overflow-hidden text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D48]"
                >
                  {item.thumbnailDataUrl ? (
                    <img
                      src={item.thumbnailDataUrl}
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-zinc-900 via-zinc-800 to-zinc-900 text-zinc-300 p-4">
                      {item.isAudioOnly ? (
                        <Music className="w-8 h-8 text-zinc-400 mb-2" />
                      ) : (
                        <Film className="w-8 h-8 text-zinc-400 mb-2" />
                      )}
                      <span className="text-xs font-mono text-zinc-400">
                        {item.platform}
                      </span>
                    </div>
                  )}

                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/25">
                    <span className="w-11 h-11 rounded-full bg-white text-zinc-950 flex items-center justify-center shadow-lg">
                      <Play className="w-4 h-4 ml-0.5 fill-current" />
                    </span>
                  </div>

                  <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/80 via-black/35 to-transparent flex items-end justify-between">
                    <span className="text-xs font-mono font-medium text-white tabular-nums">
                      {resLabel}
                    </span>
                    <span className="text-xs font-mono text-white/90 tabular-nums">
                      {formatDuration(item.duration)}
                    </span>
                  </div>
                </button>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <button
                      type="button"
                      onClick={() => onSelectItem(item)}
                      className="text-left w-full cursor-pointer"
                    >
                      <h3 className="font-display text-base font-semibold text-zinc-950 line-clamp-1 group-hover:text-[#E11D48] transition-colors">
                        {item.title}
                      </h3>
                    </button>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-zinc-500">
                      <span className="text-zinc-700 font-medium">{item.platform}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {formatBytes(item.fileSize)}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{formatSavedDate(item.createdAt)}</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-zinc-100 flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => void handleSaveToDevice(item)}
                      className="h-9 px-3.5 rounded-lg bg-zinc-950 hover:bg-zinc-800 text-white text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                    >
                      {mobileShare ? (
                        <>
                          <Share2 className="w-3.5 h-3.5" />
                          <span>Save to Photos</span>
                        </>
                      ) : (
                        <>
                          <Download className="w-3.5 h-3.5" />
                          <span>Save to Device</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => onDeleteItem(item.id)}
                      aria-label={`Remove ${item.title}`}
                      className="h-9 px-2.5 rounded-lg text-zinc-500 hover:text-red-600 hover:bg-red-50 transition-colors inline-flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
