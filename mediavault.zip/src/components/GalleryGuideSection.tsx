const STEPS = [
  {
    step: '01. Resolve Highest Stream',
    title: 'Inspect every quality tier before downloading',
    body: 'Paste any social video link. FrameVault probes the source manifest for 4K, 1440p, 1080p, 720p, and audio-only streams so you choose the exact resolution and bitrate you want.',
  },
  {
    step: '02. Gallery-Safe H.264 Remux',
    title: 'Never hit "Unsupported Format" in Photos',
    body: 'Many social platforms serve VP9, AV1, or split DASH tracks that iPhone Photos and Android Galleries reject. FrameVault automatically remuxes or transcodes into H.264 + AAC with fast-start MP4 atoms.',
  },
  {
    step: '03. Direct Device & Vault Save',
    title: 'Save to Camera Roll or local offline vault',
    body: 'On iOS and Android, use Save to Photos to open the native share sheet and tap Save Video straight into your gallery. On desktop, save directly into your Pictures or Videos folder and keep a copy in your local FrameVault gallery.',
  },
];

export function GalleryGuideSection() {
  return (
    <section
      id="guide"
      className="max-w-6xl mx-auto px-6 py-20 border-t border-zinc-200"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        <div className="lg:col-span-5">
          <p className="text-sm font-medium text-[#E11D48] mb-2">
            Direct Gallery Pipeline
          </p>
          <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight text-zinc-950 [text-wrap:balance]">
            From social link to Camera Roll in three steps
          </h2>
          <p className="mt-4 text-base text-zinc-600 leading-relaxed">
            Every clip is stored locally in your browser&apos;s IndexedDB media vault and exported as a clean, standard MP4 file. No cloud accounts or external watermarks.
          </p>

          <div className="mt-8 p-6 rounded-2xl bg-white border border-zinc-200">
            <div className="flex items-center justify-between text-xs font-mono text-zinc-500 pb-3 border-b border-zinc-100">
              <span>Target Container</span>
              <span className="text-zinc-950 font-medium">MPEG-4 (.mp4)</span>
            </div>
            <div className="flex items-center justify-between text-xs font-mono text-zinc-500 py-3 border-b border-zinc-100">
              <span>Video Codec</span>
              <span className="text-zinc-950 font-medium">H.264 / AVC (yuv420p)</span>
            </div>
            <div className="flex items-center justify-between text-xs font-mono text-zinc-500 py-3 border-b border-zinc-100">
              <span>Audio Codec</span>
              <span className="text-zinc-950 font-medium">AAC-LC · 192 kbps</span>
            </div>
            <div className="flex items-center justify-between text-xs font-mono text-zinc-500 pt-3">
              <span>Atom Layout</span>
              <span className="text-zinc-950 font-medium">moov +faststart</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-7 space-y-8">
          {STEPS.map((item) => (
            <div
              key={item.step}
              className="p-6 md:p-8 rounded-2xl bg-white border border-zinc-200"
            >
              <p className="text-xs font-mono font-medium text-[#E11D48]">
                {item.step}
              </p>
              <h3 className="mt-2 font-display text-xl font-semibold text-zinc-950">
                {item.title}
              </h3>
              <p className="mt-2 text-sm md:text-base text-zinc-600 leading-relaxed">
                {item.body}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
