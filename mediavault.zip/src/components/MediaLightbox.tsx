import { useEffect, useState } from 'react';
import { Download, Music, Share2, Trash2, X } from 'lucide-react';
import type { GalleryItem } from '../types.ts';
import {
  formatBytes,
  formatDuration,
  formatResolutionLabel,
  formatSavedDate,
} from '../lib/formatters.ts';
import {
  canShareToPhotos,
  saveToDeviceDisk,
  shareToDevicePhotos,
} from '../lib/saveToGallery.ts';

interface MediaLightboxProps {
  item: GalleryItem | null;
  onClose: () => void;
  onDelete: (id: string) => void;
}

export function MediaLightbox({ item, onClose, onDelete }: MediaLightboxProps) {
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    if (!item) {
      setMediaUrl(null);
      return;
    }
    const url = URL.createObjectURL(item.blob);
    setMediaUrl(url);
    setFeedback(null);
    return () => {
      URL.revokeObjectURL(url);
    };
  }, [item]);

  useEffect(() => {
    if (!item) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [item, onClose]);

  if (!item || !mediaUrl) return null;

  const shareSupported = canShareToPhotos(item.mimeType, item.filename);

  async function handleSharePhotos() {
    if (!item) return;
    const res = await shareToDevicePhotos(item.blob, item.filename, item.title);
    if (res === 'shared') {
      setFeedback('Share sheet opened — tap "Save Video" to store directly in Photos.');
    } else if (res === 'unsupported') {
      await handleDownloadFile();
    }
  }

  async function handleDownloadFile() {
    if (!item) return;
    const res = await saveToDeviceDisk(item.blob, item.filename);
    if (res !== 'cancelled') {
      setFeedback(`Saved "${item.filename}" to your device.`);
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={item.title}
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 md:p-8"
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden text-white shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Bar */}
        <div className="px-5 py-4 border-b border-zinc-800 flex items-center justify-between gap-4">
          <div className="min-w-0">
            <p className="text-xs text-zinc-400 truncate">
              {item.platform} · {item.author} · {formatSavedDate(item.createdAt)}
            </p>
            <h3 className="font-display text-lg font-semibold text-white truncate">
              {item.title}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close player"
            className="w-9 h-9 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-200 flex items-center justify-center shrink-0 cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Video / Audio Viewport */}
        <div className="bg-black flex items-center justify-center max-h-[65vh]">
          {item.isAudioOnly ? (
            <div className="w-full py-16 px-8 flex flex-col items-center justify-center gap-6">
              <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-300">
                <Music className="w-7 h-7" />
              </div>
              <audio src={mediaUrl} controls autoPlay className="w-full max-w-lg" />
            </div>
          ) : (
            <video
              src={mediaUrl}
              controls
              playsInline
              autoPlay
              className="w-full max-h-[65vh] object-contain"
            />
          )}
        </div>

        {/* Technical Metadata & Actions */}
        <div className="p-5 border-t border-zinc-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs font-mono text-zinc-300 tabular-nums">
            <span>
              {formatResolutionLabel(item.width, item.height, item.isAudioOnly)}
              {item.width && item.height ? ` (${item.width}×${item.height})` : ''}
            </span>
            <span>{formatBytes(item.fileSize)}</span>
            {item.duration ? <span>{formatDuration(item.duration)}</span> : null}
            {item.vcodec && item.vcodec !== 'none' ? (
              <span className="uppercase">
                {item.vcodec}
                {item.acodec ? ` / ${item.acodec}` : ''}
              </span>
            ) : null}
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {shareSupported ? (
              <button
                type="button"
                onClick={() => void handleSharePhotos()}
                className="h-10 px-4 rounded-xl bg-[#E11D48] hover:bg-[#BE123C] text-white text-xs font-medium inline-flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Save to Photos</span>
              </button>
            ) : null}

            <button
              type="button"
              onClick={() => void handleDownloadFile()}
              className={`h-10 px-4 rounded-xl text-xs font-medium inline-flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                shareSupported
                  ? 'bg-zinc-800 hover:bg-zinc-700 text-white'
                  : 'bg-[#E11D48] hover:bg-[#BE123C] text-white'
              }`}
            >
              <Download className="w-3.5 h-3.5" />
              <span>Save File to Device</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onDelete(item.id);
                onClose();
              }}
              className="h-10 px-3.5 rounded-xl bg-zinc-900 hover:bg-red-950 text-zinc-300 hover:text-red-300 text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Remove</span>
            </button>
          </div>
        </div>

        {feedback ? (
          <div className="px-5 pb-4 text-xs text-emerald-400">{feedback}</div>
        ) : null}
      </div>
    </div>
  );
}
