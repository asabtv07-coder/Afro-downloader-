interface SaveFilePickerWindow extends Window {
  showSaveFilePicker?: (options?: {
    suggestedName?: string;
    types?: Array<{
      description?: string;
      accept: Record<string, string[]>;
    }>;
  }) => Promise<{
    createWritable: () => Promise<{
      write: (data: Blob) => Promise<void>;
      close: () => Promise<void>;
    }>;
  }>;
}

export function canShareToPhotos(mimeType: string, filename: string): boolean {
  if (typeof navigator === 'undefined' || !navigator.share || !navigator.canShare) {
    return false;
  }
  try {
    const testFile = new File([new Uint8Array([0])], filename, { type: mimeType });
    return navigator.canShare({ files: [testFile] });
  } catch {
    return false;
  }
}

export async function shareToDevicePhotos(
  blob: Blob,
  filename: string,
  title: string,
): Promise<'shared' | 'cancelled' | 'unsupported'> {
  if (typeof navigator === 'undefined' || !navigator.share || !navigator.canShare) {
    return 'unsupported';
  }
  try {
    const file = new File([blob], filename, { type: blob.type || 'video/mp4' });
    if (!navigator.canShare({ files: [file] })) {
      return 'unsupported';
    }
    await navigator.share({
      files: [file],
      title,
    });
    return 'shared';
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      return 'cancelled';
    }
    return 'unsupported';
  }
}

export async function saveToDeviceDisk(
  blob: Blob,
  filename: string,
): Promise<'saved-picker' | 'downloaded' | 'cancelled'> {
  const win = window as SaveFilePickerWindow;
  const isMp4 = filename.toLowerCase().endsWith('.mp4');

  if (typeof win.showSaveFilePicker === 'function') {
    try {
      const handle = await win.showSaveFilePicker({
        suggestedName: filename,
        types: [
          {
            description: isMp4 ? 'MP4 Video (Gallery Ready)' : 'Media File',
            accept: isMp4
              ? { 'video/mp4': ['.mp4'] }
              : { [blob.type || 'application/octet-stream']: [`.${filename.split('.').pop() || 'mp4'}`] },
          },
        ],
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return 'saved-picker';
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        return 'cancelled';
      }
      // Fall back to standard browser download if File System Access API fails inside iframe
    }
  }

  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = filename;
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 10000);
  return 'downloaded';
}
